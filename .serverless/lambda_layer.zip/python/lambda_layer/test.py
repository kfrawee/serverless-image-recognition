def test_layer_functions() -> str:
    return "it is working; i hope"