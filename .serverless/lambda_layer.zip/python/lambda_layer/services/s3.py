"""
Helper functions for interacting with s3 service
"""