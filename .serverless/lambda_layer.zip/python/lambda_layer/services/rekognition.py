"""
Helper functions for interacting with rekognition service
"""