"""
Helper functions for interacting with dynamodb service
"""