import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='kfrawee',
    application_name='image-recognition',
    app_uid='tVbyGLl2Bzhwvz4hCm',
    org_uid='6ee047a4-5058-462c-8094-6b65ee7a309f',
    deployment_uid='09baa6a9-e26e-4bc6-9676-7b645eed2456',
    service_name='image-recognition',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'image-recognition-dev-test', 'timeout': 29}
try:
    user_handler = serverless_sdk.get_user_handler('src.handlers.blobs.index.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
