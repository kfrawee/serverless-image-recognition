"""
Handler for label image once it is uploaded to s3
"""